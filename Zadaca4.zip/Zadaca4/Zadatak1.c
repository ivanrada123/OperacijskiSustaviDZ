#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <unistd.h>

#define N 10 // broj praznih mjesta u vrtuljku

sem_t sem_vrtuljak; // sem za vrtuljak
sem_t sem_posjetitelj; // sem za posjetitelje
int broj_posjetitelja = 0; // broj posjetitelja koji su trenutno ukrcani
int stop = 0; // varijabla koja označava kada treba zaustaviti rad programa
pthread_mutex_t broj_posjetitelja_mux = PTHREAD_MUTEX_INITIALIZER; 

void *vrtuljak(void *arg)
{
    while (1)
    {
        sem_wait(&sem_vrtuljak); // čeka dok se vrtuljak napuni
        if(stop) pthread_exit(0); // ako je stop postavljen na 1, prekida se rad vrtuljka
        printf("Vrtuljak kreće! \n\n");
        sleep(3); // simulira vožnju
        sem_post(&sem_posjetitelj); // dopušta posjetiteljima da siđu
    }
}

void *posjetitelj(void *arg)
{
    while (1)
    {
        sem_wait(&sem_posjetitelj); // čeka dok se prethodni posjetitelji ne sidju
        if(stop) pthread_exit(0); // ako je stop postavljen na 1,prekida se rad posjetitelja
pthread_mutex_lock(&broj_posjetitelja_mux);
if (broj_posjetitelja < N)
{
broj_posjetitelja++;
printf("Posjetitelj se ukrcao, trenutno ukrcano: %d\n\n", broj_posjetitelja);
if (broj_posjetitelja == N)
{
sem_post(&sem_vrtuljak); // dopušta vrtuljaku da krene
}
}
else
{
printf("Nema više mjesta, posjetitelj čeka.\n\n");
}
pthread_mutex_unlock(&broj_posjetitelja_mux);
sleep(1); // simulira čekanje
pthread_mutex_lock(&broj_posjetitelja_mux);
if(broj_posjetitelja == 0)
{
sem_post(&sem_posjetitelj);
}
broj_posjetitelja--;
pthread_mutex_unlock(&broj_posjetitelja_mux);
}
}

int main(void)
{
sem_init(&sem_vrtuljak, 0, 0);
sem_init(&sem_posjetitelj, 0, 1);
pthread_t vrtuljak_thread, posjetitelj_thread;
pthread_create(&vrtuljak_thread, NULL, vrtuljak, NULL);
pthread_create(&posjetitelj_thread, NULL, posjetitelj, NULL);

sleep(30); // simulacija rada programa 30 sekundi
stop = 1; // postavljanje stop varijable na 1
sem_post(&sem_posjetitelj); 
pthread_join(vrtuljak_thread, NULL);
pthread_join(posjetitelj_thread, NULL);

sem_destroy(&sem_vrtuljak);
sem_destroy(&sem_posjetitelj);
pthread_mutex_destroy(&broj_posjetitelja_mux);

return 0;
}
