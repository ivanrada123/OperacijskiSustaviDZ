#include <stdio.h>
#include <semaphore.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <fcntl.h>
#define N 5
#define M 15
#define SEMNAME_MJESTA "mjesta"

void posjetitelj(int i){

	sem_t* mjesta = sem_open(SEMNAME_MJESTA, 0);
	while(1){
		sem_wait(mjesta);
		printf("Proces %d je usao\n", i);
		sleep(3);	
	}	
}

void vrtuljak(){
int br = 0;
	sem_t* mjesta = sem_open(SEMNAME_MJESTA,0);
	int * value = malloc(sizeof(int));
	while(1){
		do{
			sem_getvalue(mjesta, value);			
			printf("Broj slobodnih mjesta: %d\n", *value);
			sleep(2);
		}while(*value != 0);
	
	sleep(2);
	printf("Vrtuljak se vrti %d\n", br++);
	sleep(3);
	printf("Vrtuljak se zaustavio\n");
	sleep(2);
	for(int i=0;i<N; i++){
	sem_post(mjesta);
	printf("Sjedalo br %d na vrtuljku je prazno\n", i+1);
	}
	sleep(2);
	}
	sleep(2);
}


void main(){
       
	sem_t* mjesta = sem_open(SEMNAME_MJESTA, O_CREAT, 0644, N);
	
	for(int i=0;i<N; i++){
	sem_post(mjesta);
	}
	
	if(fork() == 0){
		vrtuljak();
	}
	
	sleep(2);
	for(int i = 0; i<M;i++){
		if(fork() == 0){
			posjetitelj(i);
		}
	}
	

	for(int i = 0; i<M+1; i++){
		wait(NULL);
	}
	
	sem_destroy(mjesta);
	
}
  
