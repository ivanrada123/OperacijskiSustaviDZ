#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>

int prekid = 0;
int broj;
FILE * status;
FILE * obrada;


void sigint_handler (int sig) {
        int izbor;
        printf("\nOdaberite:\n1) Nastaviti prethodni proces\n2) Ispisati trenutni status\n3) Save status i napustiti program\n4) Napustiti program bez spremanja\n");
        scanf("%d", &izbor);
        switch (izbor) {
                case 1:
                        break;
                case 2:
                        kill(getpid(), SIGUSR1);
                        break;
                case 3:
                        kill(getpid(), SIGTERM);
                        break;
                case 4:
                        exit(0);
                        break;
                default:
                        break;
    }
}

void sigusr1_handler(int sig) {
        printf("Broj statusa: %d\n", broj);
}

void sigterm_handler(int sig) {
        status = fopen("status.txt", "w");
        fprintf(status, "%d", broj);
        fclose(status);
        exit(0);
}

int main(int argc, char *argv) {
        
        signal(SIGINT, sigint_handler);
        signal(SIGUSR1, sigusr1_handler);
        signal(SIGTERM, sigterm_handler);

        status = fopen("status.txt", "r");
        fscanf(status, "%d", &broj);
        fclose(status);
        if (broj == 0) {
                int obradaBr;
                obrada = fopen("obrada.txt", "r");
                while (!feof(obrada)) {
                        fscanf(obrada, "%d", &obradaBr);
                }
                broj = round(sqrt(obradaBr));
        }
        
        obrada = fopen("obrada.txt", "a");
        while (1) {
                if(!prekid) {
                        fprintf(obrada, "%d\n", broj * broj);
                        broj++;
                }
                status = fopen("status.txt", "w");
                fprintf(status, "0");
                fclose(status);
                sleep(5);
        }
        fclose(obrada);

}
